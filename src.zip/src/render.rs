use tui::layout::{Constraint, Direction, Layout, Rect, Corner};
use tui::widgets::{Block, Borders, Widget, Sparkline, Gauge, Row, Table, List, Text, Paragraph};
use tui::style::{Color, Style};
use tui::backend::Backend;
use tui::terminal::Frame;
use pretty_bytes::converter::convert;

use crate::app::App;
use crate::process::Process;
use crate::util::*;

// Helper function to make creating layouts easier
pub fn define_layout (direction: Direction, constraints: &[Constraint], location: Rect) -> Vec<Rect> {
    Layout::default()
        .direction(direction)
        .constraints(constraints)
        .split(location)
}

pub fn render_console_layout<B> (f: &mut Frame<B>, layout: Rect, app: &App)
        where
        B: Backend {
            let log_text = app.console.history.iter().map(Text::raw);
            List::new(log_text)
                .block(
                    Block::default()
                        .borders(Borders::ALL)
                        .title("Console")
                )
                .start_corner(Corner::BottomLeft)
                .render(f, layout);
}

pub fn render_sparklines_layout<B> (f: &mut Frame<B>, layout: &[Rect], app: &App)
    where
    B: Backend {
    Sparkline::default()
        .block(
            Block::default()
                .title(&format!("CPU Usage: {}% | Number of Cores: {}", app.system.cpu_current_usage, app.system.cpu_num_cores))
                .borders(Borders::LEFT | Borders::RIGHT | Borders::TOP)
                .border_style(Style::default().fg(Color::Green))
        )
        .data(&app.system.cpu_usage_history.as_slice())
        .style(Style::default().fg(Color::Yellow))
        .max(100)
        .render(f, layout[0]);

    Sparkline::default()
        .block(
            Block::default()
                .title(&format!("Memory Used: {} | Memory Free: {}", convert(app.system.mem_used as f64 * 1000.0), convert(app.system.mem_free as f64 * 1000.0)))
                .borders(Borders::LEFT | Borders::RIGHT | Borders::TOP)
                .border_style(Style::default().fg(Color::Green))
        )
        .data(&app.system.mem_usage_history)
        .style(Style::default().fg(Color::Blue))
        .max(app.system.mem_total)
        .render(f, layout[1]);
}

pub fn render_cpu_cores_layout<B> (f: &mut Frame<B>, layout: &[Rect], app: &App)
    where
    B: Backend {
    // Creates a guage for each cpu core
    for (i, core_usage) in app.system.cpu_core_usages.iter().enumerate() {
        Gauge::default()
            .block(
                Block::default()
                .title(&format!("Core {}", i + 1))
                .borders(Borders::ALL)
                .border_style(Style::default().fg(Color::Green))
            )
            .style(Style::default().fg(Color::Green))
            .percent(*core_usage)
            .render(f, layout[i]);
    }
}

pub fn render_processes_layout<B> (f: &mut Frame<B>, layout: Rect, app: &mut App)
    where
    B: Backend {

    let mut processes: Vec<Process> = app.system.processes.clone();

    match app.processes_sort_by {
        SortBy::PID => processes.sort_by(|a, b| a.pid.partial_cmp(&b.pid).unwrap()),
        SortBy::Name => processes.sort_by(|a, b| a.name.partial_cmp(&b.name).unwrap()),
        SortBy::CPU => processes.sort_by(|a, b| a.cpu.partial_cmp(&b.cpu).unwrap()),
        SortBy::Memory => processes.sort_by(|a, b| a.mem.partial_cmp(&b.mem).unwrap()),
    }
    
    if app.processes_sort_direction == SortDirection::DESC {
        processes.reverse();
    }

    static mut headers: [&str; 5] = ["PID", "Name", "CPU", "Memory", "Nice"];
    let mut fmt_processes: Vec<Vec<String>> = processes.iter().map(|process| process.format0()).collect();
    
    match app.processes_add_by{
        
        Addby::ppid => {
            unsafe{
            headers = add_ppid( headers);
        }
        
            app.processes_add_by = Addby::Memory;
        },
        Addby::CPU => {
            unsafe{
            headers = add_cpu(headers);
            
            app.processes_add_by = Addby::Memory;
            
        }
            
        },
        Addby::Memory => unsafe{
            headers = add_mem(headers);
            
            app.processes_add_by = Addby::Def;
            
        },
        Addby::state => unsafe{
            headers = add_state(headers);
            
            app.processes_add_by = Addby::Def;
            
        },
        Addby::Nice => unsafe{
            headers = add_Nice(headers);
            
            app.processes_add_by = Addby::Def;
        },  
        Addby::Def => unsafe{
            headers = headers;
        }
            
        
    }
    unsafe{
        if (headers[2] == "CPU" && headers[3] == "Memory" && headers[4] == "Nice"){
            fmt_processes = processes.iter().map(|process| process.format0()).collect();
        }

        if (headers[2] == "CPU" && headers[3] == "Memory" && headers[4] == "state"){
            fmt_processes = processes.iter().map(|process| process.format1()).collect();
        }

        if (headers[2] == "CPU" && headers[3] == "Memory" && headers[4] == "ppid"){
            fmt_processes = processes.iter().map(|process| process.format2()).collect();
        }

        if (headers[2] == "CPU" && headers[3] == "Nice" && headers[4] == "Memory"){
            fmt_processes = processes.iter().map(|process| process.format3()).collect();
        }

        if (headers[2] == "CPU" && headers[3] == "Nice" && headers[4] == "state"){
            fmt_processes = processes.iter().map(|process| process.format4()).collect();
        }

        if (headers[2] == "CPU" && headers[3] == "Nice" && headers[4] == "ppid"){
            fmt_processes = processes.iter().map(|process| process.format5()).collect();
        }

        if (headers[2] == "CPU" && headers[3] == "state" && headers[4] == "Memory"){
            fmt_processes = processes.iter().map(|process| process.format6()).collect();
        }

        if (headers[2] == "CPU" && headers[3] == "state" && headers[4] == "Nice"){
            fmt_processes = processes.iter().map(|process| process.format7()).collect();
        }

        if (headers[2] == "CPU" && headers[3] == "state" && headers[4] == "ppid"){
            fmt_processes = processes.iter().map(|process| process.format8()).collect();
        }

        if (headers[2] == "CPU" && headers[3] == "ppid" && headers[4] == "Memory"){
            fmt_processes = processes.iter().map(|process| process.format9()).collect();
        }

        if (headers[2] == "CPU" && headers[3] == "ppid" && headers[4] == "Nice"){
            fmt_processes = processes.iter().map(|process| process.format10()).collect();
        }

        if (headers[2] == "CPU" && headers[3] == "ppid" && headers[4] == "state"){
            fmt_processes = processes.iter().map(|process| process.format11()).collect();
        }

        if (headers[2] == "Memory" && headers[3] == "CPU" && headers[4] == "Nice"){
            fmt_processes = processes.iter().map(|process| process.format12()).collect();
        }

        if (headers[2] == "Memory" && headers[3] == "CPU" && headers[4] == "state"){
            fmt_processes = processes.iter().map(|process| process.format13()).collect();
        }
        
        if (headers[2] == "Memory" && headers[3] == "CPU" && headers[4] == "ppid"){
            fmt_processes = processes.iter().map(|process| process.format14()).collect();
        }

        if (headers[2] == "Memory" && headers[3] == "Nice" && headers[4] == "CPU"){
            fmt_processes = processes.iter().map(|process| process.format15()).collect();
        }

        if (headers[2] == "Memory" && headers[3] == "Nice" && headers[4] == "state"){
            fmt_processes = processes.iter().map(|process| process.format16()).collect();
        }

        if (headers[2] == "Memory" && headers[3] == "Nice" && headers[4] == "ppid"){
            fmt_processes = processes.iter().map(|process| process.format17()).collect();
        }
        
        if (headers[2] == "Memory" && headers[3] == "state" && headers[4] == "CPU"){
            fmt_processes = processes.iter().map(|process| process.format18()).collect();
        }
        
        if (headers[2] == "Memory" && headers[3] == "state" && headers[4] == "Nice"){
            fmt_processes = processes.iter().map(|process| process.format19()).collect();
        }

        if (headers[2] == "Memory" && headers[3] == "state" && headers[4] == "ppid"){
            fmt_processes = processes.iter().map(|process| process.format20()).collect();
        }

        if (headers[2] == "Memory" && headers[3] == "ppid" && headers[4] == "CPU"){
            fmt_processes = processes.iter().map(|process| process.format21()).collect();
        }


        if (headers[2] == "Memory" && headers[3] == "ppid" && headers[4] == "Nice"){
            fmt_processes = processes.iter().map(|process| process.format22()).collect();
        }

        if (headers[2] == "Memory" && headers[3] == "ppid" && headers[4] == "state"){
            fmt_processes = processes.iter().map(|process| process.format23()).collect();
        }

        if (headers[2] == "Nice" && headers[3] == "CPU" && headers[4] == "Memory"){
            fmt_processes = processes.iter().map(|process| process.format24()).collect();
        }

        if (headers[2] == "Nice" && headers[3] == "CPU" && headers[4] == "state"){
            fmt_processes = processes.iter().map(|process| process.format25()).collect();
        }

        if (headers[2] == "Nice" && headers[3] == "CPU" && headers[4] == "ppid"){
            fmt_processes = processes.iter().map(|process| process.format26()).collect();
        }

        if (headers[2] == "Nice" && headers[3] == "Memory" && headers[4] == "CPU"){
            fmt_processes = processes.iter().map(|process| process.format27()).collect();
        }

        if (headers[2] == "Nice" && headers[3] == "Memory" && headers[4] == "state"){
            fmt_processes = processes.iter().map(|process| process.format28()).collect();
        }

        if (headers[2] == "Nice" && headers[3] == "CPU" && headers[4] == "ppid"){
            fmt_processes = processes.iter().map(|process| process.format29()).collect();
        }

        if (headers[2] == "Nice" && headers[3] == "state" && headers[4] == "CPU"){
            fmt_processes = processes.iter().map(|process| process.format30()).collect();
        }

        if (headers[2] == "Nice" && headers[3] == "state" && headers[4] == "Memory"){
            fmt_processes = processes.iter().map(|process| process.format31()).collect();
        }

        if (headers[2] == "Nice" && headers[3] == "state" && headers[4] == "ppid"){
            fmt_processes = processes.iter().map(|process| process.format32()).collect();
        }

        if (headers[2] == "Nice" && headers[3] == "ppid" && headers[4] == "CPU"){
            fmt_processes = processes.iter().map(|process| process.format33()).collect();
        }

        if (headers[2] == "Nice" && headers[3] == "ppid" && headers[4] == "Memory"){
            fmt_processes = processes.iter().map(|process| process.format34()).collect();
        }

        if (headers[2] == "Nice" && headers[3] == "ppid" && headers[4] == "state"){
            fmt_processes = processes.iter().map(|process| process.format35()).collect();
        }
        
        if (headers[2] == "state" && headers[3] == "CPU" && headers[4] == "Memory"){
            fmt_processes = processes.iter().map(|process| process.format36()).collect();
        }

        if (headers[2] == "state" && headers[3] == "CPU" && headers[4] == "Nice"){
            fmt_processes = processes.iter().map(|process| process.format37()).collect();
        }
        
        if (headers[2] == "state" && headers[3] == "CPU" && headers[4] == "ppid"){
            fmt_processes = processes.iter().map(|process| process.format38()).collect();
        }

        if (headers[2] == "state" && headers[3] == "Memory" && headers[4] == "CPU"){
            fmt_processes = processes.iter().map(|process| process.format39()).collect();
        }

        if (headers[2] == "state" && headers[3] == "Memory" && headers[4] == "Nice"){
            fmt_processes = processes.iter().map(|process| process.format40()).collect();
        }

        if (headers[2] == "state" && headers[3] == "Memory" && headers[4] == "ppid"){
            fmt_processes = processes.iter().map(|process| process.format41()).collect();
        }

        if (headers[2] == "state" && headers[3] == "Nice" && headers[4] == "CPU"){
            fmt_processes = processes.iter().map(|process| process.format42()).collect();
        }

        if (headers[2] == "state" && headers[3] == "Nice" && headers[4] == "Memory"){
            fmt_processes = processes.iter().map(|process| process.format43()).collect();
        }

        if (headers[2] == "state" && headers[3] == "Nice" && headers[4] == "ppid"){
            fmt_processes = processes.iter().map(|process| process.format44()).collect();
        }

        if (headers[2] == "state" && headers[3] == "ppid" && headers[4] == "CPU"){
            fmt_processes = processes.iter().map(|process| process.format45()).collect();
        }

        if (headers[2] == "state" && headers[3] == "ppid" && headers[4] == "Memory"){
            fmt_processes = processes.iter().map(|process| process.format46()).collect();
        }

        if (headers[2] == "state" && headers[3] == "ppid" && headers[4] == "Nice"){
            fmt_processes = processes.iter().map(|process| process.format47()).collect();
        }

        if (headers[2] == "ppid" && headers[3] == "CPU" && headers[4] == "Memory"){
            fmt_processes = processes.iter().map(|process| process.format48()).collect();
        }

        if (headers[2] == "ppid" && headers[3] == "CPU" && headers[4] == "Nice"){
            fmt_processes = processes.iter().map(|process| process.format49()).collect();
        }

        if (headers[2] == "ppid" && headers[3] == "CPU" && headers[4] == "state"){
            fmt_processes = processes.iter().map(|process| process.format50()).collect();
        }

        if (headers[2] == "ppid" && headers[3] == "Memory" && headers[4] == "CPU"){
            fmt_processes = processes.iter().map(|process| process.format51()).collect();
        }

        if (headers[2] == "ppid" && headers[3] == "Memory" && headers[4] == "Nice"){
            fmt_processes = processes.iter().map(|process| process.format52()).collect();
        }

        if (headers[2] == "ppid" && headers[3] == "Memory" && headers[4] == "state"){
            fmt_processes = processes.iter().map(|process| process.format53()).collect();
        }

        if (headers[2] == "ppid" && headers[3] == "Nice" && headers[4] == "CPU"){
            fmt_processes = processes.iter().map(|process| process.format54()).collect();
        }

        if (headers[2] == "ppid" && headers[3] == "Nice" && headers[4] == "Memory"){
            fmt_processes = processes.iter().map(|process| process.format55()).collect();
        }

        if (headers[2] == "ppid" && headers[3] == "Nice" && headers[4] == "state"){
            fmt_processes = processes.iter().map(|process| process.format56()).collect();
        }

        if (headers[2] == "ppid" && headers[3] == "state" && headers[4] == "CPU"){
            fmt_processes = processes.iter().map(|process| process.format57()).collect();
        }

        if (headers[2] == "ppid" && headers[3] == "state" && headers[4] == "Memory"){
            fmt_processes = processes.iter().map(|process| process.format58()).collect();
        }

        if (headers[2] == "ppid" && headers[3] == "state" && headers[4] == "Nice"){
            fmt_processes = processes.iter().map(|process| process.format59()).collect();
        }
    }
    let rows = fmt_processes.iter().map(|process|
        Row::Data(process.iter())
    );

    // TODO: Show visual indication of sort direction
    Table::new(unsafe{headers.iter()}, rows)
        .block(Block::default().borders(Borders::ALL).title("Processes"))
        .widths(&[6, 25, 9, 9, 9 ])
        .column_spacing(5)
        .render(f, layout);
}


fn add_cpu(headers: [&str; 5]) -> [&str; 5] {
        if (!(headers[2] == "CPU" || headers[3] == "CPU" || headers[4] == "CPU")){
            let mut headerss = [headers[0], headers[1], headers[3], headers[4], "CPU"];
            return headerss;
        }
        else{
            return headers;
        }
    
}

// TODO: Show visual indication of invalid command
pub fn render_input_layout<B> (f: &mut Frame<B>, layout: Rect, app: &App)
    where B: Backend {
    Paragraph::new([Text::raw(&app.console.input)].iter())
        .style(Style::default().fg(Color::White))
        .block(Block::default().borders(Borders::ALL).title("Input"))
        .render(f, layout);
}


pub fn add_ppid( headers: [&str; 5])-> [&str;5]{
    let headerss = [headers[0], headers[1], headers[3], headers[4], "ppid"];
    headerss
}

fn add_mem(headers: [&str; 5]) -> [&str; 5] {
    if (!(headers[2] == "Memory" || headers[3] == "Memory" || headers[4] == "Memory")){
        let mut headerss = [headers[0], headers[1], headers[3], headers[4], "Memory"];
        return headerss;
    }
    else{
        return headers;
    }
}
fn add_state(headers: [&str; 5]) -> [&str; 5] {
    if (!(headers[2] == "state" || headers[3] == "state" || headers[4] == "state")){
        let mut headerss = [headers[0], headers[1], headers[3], headers[4], "state"];
        return headerss;
    }
    else{
        return headers;
    }
}
fn add_Nice(headers: [&str; 5]) -> [&str; 5] {
    if (!(headers[2] == "Nice" || headers[3] == "Nice" || headers[4] == "Nice")){
        let mut headerss = [headers[0], headers[1], headers[3], headers[4], "Nice"];
        return headerss;
    }
    else{
        return headers;
    }
}